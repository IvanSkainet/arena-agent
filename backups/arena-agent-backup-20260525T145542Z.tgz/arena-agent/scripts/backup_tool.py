#!/usr/bin/env python3
from __future__ import annotations
import datetime as dt, os, tarfile
from pathlib import Path
ROOT=Path(os.environ.get('ARENA_AGENT_HOME', str(Path.home()/'arena-agent'))).expanduser(); HOME=Path.home(); B=ROOT/'backups'
INCLUDE=[
 'arena-agent/bin','arena-agent/scripts','arena-agent/skills','arena-agent/memory','arena-agent/mcp','arena-agent/js/package.json','arena-agent/js/package-lock.json',
 '.config/systemd/user/arena-local-bridge.service','.config/systemd/user/arena-task-runner.service','.config/systemd/user/arena-mcp-stream.service',
 'arena-local-bridge/local_bridge.py','arena-local-bridge/README_RU.md']
EXCLUDES=['token.txt','.env','.env.','secrets/','node_modules/','.venv/','__pycache__/']
def skip(p:str)->bool: return any(x in p for x in EXCLUDES)
def main():
    B.mkdir(parents=True, exist_ok=True); out=B/f'arena-agent-backup-{dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")}.tgz'
    with tarfile.open(out,'w:gz') as tar:
        for rel in INCLUDE:
            p=HOME/rel
            if not p.exists(): continue
            if p.is_file() and not skip(str(p)): tar.add(p, arcname=rel)
            elif p.is_dir():
                for f in p.rglob('*'):
                    if f.is_file() and not skip(str(f)): tar.add(f, arcname=str(f.relative_to(HOME)))
    os.chmod(out,0o600); print(out)
if __name__=='__main__': main()
