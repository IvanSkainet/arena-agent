import sys, os, subprocess
from pathlib import Path
REPO_DIR = Path(os.environ.get("ARENA_AGENT_HOME", Path.home()/"arena-agent")) / "tools" / "superpowers"
cmd = sys.argv[1] if len(sys.argv)>1 else "list"

if cmd == "sync":
    if not REPO_DIR.exists():
        subprocess.run(f"git clone https://github.com/obra/superpowers.git {REPO_DIR}", shell=True)
    else:
        subprocess.run(f"cd {REPO_DIR} && git pull", shell=True)
    print("Superpowers synced to " + str(REPO_DIR))
elif cmd == "list":
    if not REPO_DIR.exists(): 
        print("Run 'agentctl sp sync' first.")
        sys.exit(0)
    for f in sorted(REPO_DIR.rglob("*.md")):
        if ".github" not in str(f) and ".git" not in str(f):
            print(f.relative_to(REPO_DIR))
elif cmd == "show":
    if len(sys.argv) < 3: 
        print("Provide a skill name")
        sys.exit(1)
    target = sys.argv[2]
    if not target.endswith(".md"): target += ".md"
    p = REPO_DIR / target
    if p.exists(): 
        print(p.read_text())
    else: 
        print(f"Not found: {target}")
