﻿$ErrorActionPreference = "Continue"
Set-Location "C:\Users\Ivan\arena-local-bridge"
& "C:\Users\Ivan\AppData\Local\Programs\Python\Python314\python.exe" -u "C:\Users\Ivan\arena-local-bridge\local_bridge.py" serve --root "C:\Users\Ivan" --profile owner-shell --token "K46Jn47cDn6lGRoldLyXsYrpQBpCgCoqsCYlXJ8OTys" *>> "C:\Users\Ivan\arena-agent\logs\ArenaLocalBridge.log"
