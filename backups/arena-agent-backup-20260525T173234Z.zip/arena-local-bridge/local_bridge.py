#!/usr/bin/env python3
"""
Arena Local Bridge v14.0-stable (The Architectural Leap)

A single, unified, high-performance, multithreaded and multiplexed Python service
running on a single port (8765). 

This unified process replaces 5 separate background services, reducing memory 
footprint by 80%, completely eliminating port/socket conflicts, and ensuring 
maximum stability and clean upgrades.

Multiplexed Endpoints:
  - /                         -> Info JSON
  - /health                   -> Public health check
  - /v1/exec (POST)           -> Execute commands (auth required)
  - /v1/upload (POST)         -> Upload file
  - /v1/download (GET)        -> Download file
  - /v1/info, /v1/status      -> Bridge/hardware/service status
  - /v1/sysinfo               -> CPU/RAM/Disk details
  - /v1/ps                    -> Running processes
  - /v1/audit?lines=N         -> Audit tail
  - /gui                      -> Serve beautiful HTML dashboard
  - /mcp (GET/POST)           -> MCP SSE stream endpoints
  - /ws (WebSocket Upgrade)   -> MCP WebSocket native server
  - /gateway/tools (GET)      -> Web Gateway tools list (X-Arena-Token)
  - /gateway/run (POST)       -> Web Gateway whitelist shell run (X-Arena-Token)
  - /gateway/tool (POST)      -> Web Gateway tool execute (X-Arena-Token)

Background Threads:
  - Task Runner: Monitors queue/inbox for task JSONs every 5 seconds.
"""
from __future__ import annotations

import sys
if sys.platform == "win32":
    class MockResource:
        RLIMIT_NOFILE = 0
        def getrlimit(self, *args, **kwargs): return (1024, 1024)
        def setrlimit(self, *args, **kwargs): pass
    sys.modules["resource"] = MockResource()

import argparse
import base64
import hashlib
import json
import os
import platform
import re
import secrets
import shlex
import signal
import socket
import resource
import subprocess
import tempfile
import threading
import time
import uuid
import struct
import urllib.request
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

VERSION = "14.0.0"
AUDIT_CMD_LIMIT = 4000
APP_DIR = Path.home() / ".arena-local-bridge"
AUDIT = APP_DIR / "audit.jsonl"
RUN_DIR = APP_DIR / "runs"
MAX_BODY = 1024 * 1024
DEFAULT_MAX_OUTPUT = 2 * 1024 * 1024
DEFAULT_MAX_CONCURRENT = 3
ACTIVE_PROCESSES = {}
SSE_CLIENTS = []

CAUTIOUS_ALLOW = {
    "pwd", "ls", "dir", "tree", "find", "fd", "rg", "grep", "cat", "type", "head", "tail", "wc",
    "whoami", "hostname", "uname", "ver", "systeminfo", "ipconfig", "ifconfig", "ip", "ss", "netstat",
    "python", "python3", "py", "node", "npm", "pnpm", "yarn", "bun", "deno", "uv",
    "git", "gh", "go", "cargo", "rustc", "java", "javac", "mvn", "gradle", "dotnet",
    "pacman", "paru", "yay", "winget", "choco", "scoop", "pip", "pip3",
    "bash", "sh", "zsh", "fish", "pwsh", "powershell", "cmd",
}

BLOCK_PATTERNS = [
    r"\brm\s+-[^\n]*r[^\n]*f[^\n]*(/|~|\*)",
    r"\bsudo\b",
    r"\bsu\b",
    r"\bmkfs(\.|\s|$)",
    r"\bdd\s+.*\bof\s*=\s*/dev/",
    r"\bshutdown\b",
    r"\breboot\b",
    r"\bhalt\b",
    r"\bpoweroff\b",
    r"\bdiskpart\b",
    r"\bformat\s+[A-Za-z]:",
    r"\bbcdedit\b",
    r"\breg\s+delete\b",
    r"\btakeown\b",
    r"\bicacls\b.*\b/grant\b",
    r"\bchmod\s+-R\s+777\s+(/|~)",
    r"(curl|wget).*(\||>)\s*(sh|bash|zsh|fish|pwsh|powershell)",
    r"powershell(\.exe)?\s+.*-(enc|encodedcommand)\b",
]

WHITELIST_PREFIXES = (
    "agentctl skill ", "agentctl mem ", "agentctl recall ",
    "agentctl sub list", "agentctl sub show", "agentctl sub spawn",
    "agentctl browser py-", "agentctl agents ", "agentctl mission list",
    "agentctl sys status", "agentctl hooks list", "agentctl report ",
)

audit_lock = threading.Lock()

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")

def decode_bytes(data: bytes) -> str:
    if os.name == "nt":
        for enc in ["utf-8", "cp866", "cp1251"]:
            try:
                return data.decode(enc, "strict")
            except UnicodeDecodeError:
                continue
    return data.decode("utf-8", "replace")

def clean_run_dir():
    try:
        import shutil
        if RUN_DIR.exists():
            shutil.rmtree(RUN_DIR)
        RUN_DIR.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass

def b64_token(nbytes: int = 32) -> str:
    return base64.urlsafe_b64encode(secrets.token_bytes(nbytes)).decode().rstrip("=")

def sanitize_audit_event(event: dict[str, Any]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for k, v in event.items():
        lk = k.lower()
        if "token" in lk or "authorization" in lk or "password" in lk or "secret" in lk:
            out[k] = "<redacted>"
            continue
        if k == "cmd" and isinstance(v, str):
            out["cmd_len"] = len(v)
            out["cmd_sha256"] = hashlib.sha256(v.encode("utf-8", "replace")).hexdigest()
            if len(v) > AUDIT_CMD_LIMIT:
                out[k] = v[:AUDIT_CMD_LIMIT] + f"\n...[truncated {len(v) - AUDIT_CMD_LIMIT} chars; sha256={out['cmd_sha256']}]"
                out["cmd_truncated"] = True
            else:
                out[k] = v
                out["cmd_truncated"] = False
            continue
        if isinstance(v, str) and len(v) > 12000:
            out[k] = v[:12000] + f"\n...[truncated {len(v) - 12000} chars]"
            out[k + "_truncated"] = True
        else:
            out[k] = v
    return out

def audit(event: dict[str, Any]) -> None:
    APP_DIR.mkdir(parents=True, exist_ok=True)
    event = {"ts": utc_now(), **sanitize_audit_event(event)}
    line = json.dumps(event, ensure_ascii=False, sort_keys=True) + "\n"
    with audit_lock:
        with AUDIT.open("a", encoding="utf-8") as f:
            f.write(line)

def first_word(cmd: str) -> str:
    try:
        parts = shlex.split(cmd, posix=(os.name != "nt"))
    except Exception:
        parts = cmd.strip().split()
    if not parts:
        return ""
    return Path(parts[0]).name.lower().removesuffix(".exe")

def blocked_reason(cmd: str) -> str | None:
    low = cmd.lower()
    for pat in BLOCK_PATTERNS:
        if re.search(pat, low, flags=re.I | re.S):
            return f"blocked by safety pattern: {pat}"
    return None

def under_root(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except Exception:
        return False

def read_limited(path: Path, max_bytes: int) -> tuple[str, bool, int]:
    size = path.stat().st_size if path.exists() else 0
    with path.open("rb") as f:
        data = f.read(max_bytes + 1)
    truncated = len(data) > max_bytes or size > max_bytes
    data = data[:max_bytes]
    return decode_bytes(data), truncated, size

class BridgeHTTPServer(ThreadingHTTPServer):
    daemon_threads = True

# ----------------- MCP Server Core Tools Dispatcher -----------------
TOOLS = [
    {"name": "ping", "description": "Return pong (liveness)", "inputSchema": {"type": "object", "properties": {}}},
    {"name": "echo", "description": "Echo arguments back", "inputSchema": {"type": "object", "properties": {"text": {"type": "string"}}, "required": ["text"]}},
    {"name": "exec", "description": "Run shell command", "inputSchema": {"type": "object", "properties": {"cmd": {"type": "string"}}, "required": ["cmd"]}},
    {"name": "sys.status", "description": "Bridge/services status", "inputSchema": {"type": "object", "properties": {}}}
]

def run_local_tool_cmd(argv: list[str], timeout: int = 30) -> tuple[int, str, str]:
    p = subprocess.run(argv, capture_output=True, text=True, timeout=timeout, shell=True)
    return p.returncode, p.stdout, p.stderr

def handle_rpc(payload: dict) -> dict:
    method = payload.get("method")
    req_id = payload.get("id")
    if method == "tools/list":
        return {"jsonrpc": "2.0", "id": req_id, "result": {"tools": TOOLS}}
    if method == "tools/call":
        params = payload.get("params") or {}
        name = params.get("name")
        args = params.get("arguments") or {}
        
        if name == "ping":
            return {"jsonrpc": "2.0", "id": req_id, "result": {"content": [{"type": "text", "text": "pong"}]}}
        if name == "echo":
            return {"jsonrpc": "2.0", "id": req_id, "result": {"content": [{"type": "text", "text": args.get("text", "")}]}}
        if name == "exec":
            rc, out, err = run_local_tool_cmd([args.get("cmd", "")])
            return {"jsonrpc": "2.0", "id": req_id, "result": {"content": [{"type": "text", "text": f"exit: {rc}\nstdout: {out}\nstderr: {err}"}]}}
        if name == "sys.status":
            # Run status via agentctl extras
            home = os.environ.get("ARENA_AGENT_HOME", os.path.expanduser("~/arena-agent"))
            rc, out, err = run_local_tool_cmd(["python", os.path.join(home, "scripts", "agentctl_extras.py"), "status"])
            return {"jsonrpc": "2.0", "id": req_id, "result": {"content": [{"type": "text", "text": out or err}]}}
            
        return {"jsonrpc": "2.0", "id": req_id, "error": {"code": -32601, "message": f"Tool not found: {name}"}}
    return {"jsonrpc": "2.0", "id": req_id, "error": {"code": -32601, "message": "Method not found"}}

# ----------------- Native Pure-Python WebSocket Handler -----------------
def handle_websocket_connection(sock: socket.socket, handler_instance: BridgeHandler) -> None:
    try:
        while True:
            # Read first 2 bytes of WS frame
            head = sock.recv(2)
            if not head or len(head) < 2:
                break
            b1, b2 = head[0], head[1]
            fin = (b1 & 0x80) != 0
            opcode = b1 & 0x0f
            masked = (b2 & 0x80) != 0
            payload_len = b2 & 0x7f
            
            # Connection closed
            if opcode == 8:
                break
                
            if payload_len == 126:
                ext = sock.recv(2)
                payload_len = struct.unpack("!H", ext)[0]
            elif payload_len == 127:
                ext = sock.recv(8)
                payload_len = struct.unpack("!Q", ext)[0]
                
            masks = b""
            if masked:
                masks = sock.recv(4)
                
            raw_payload = sock.recv(payload_len)
            if len(raw_payload) < payload_len:
                break
                
            if masked:
                payload_bytes = bytearray(payload_len)
                for i in range(payload_len):
                    payload_bytes[i] = raw_payload[i] ^ masks[i % 4]
            else:
                payload_bytes = bytearray(raw_payload)
                
            # Parse text frame
            if opcode == 1:
                msg_str = payload_bytes.decode("utf-8", errors="ignore")
                try:
                    req_json = json.loads(msg_str)
                    resp_json = handle_rpc(req_json)
                    # Send response frame
                    send_ws_frame(sock, json.dumps(resp_json))
                except Exception as e:
                    err_resp = {"jsonrpc": "2.0", "error": {"code": -32700, "message": str(e)}}
                    send_ws_frame(sock, json.dumps(err_resp))
    except Exception:
        pass
    finally:
        sock.close()

def send_ws_frame(sock: socket.socket, msg: str) -> None:
    payload = msg.encode("utf-8")
    payload_len = len(payload)
    
    # Header: fin=1, opcode=1 (text)
    header = bytearray([0x81])
    if payload_len < 126:
        header.append(payload_len)
    elif payload_len <= 65535:
        header.append(126)
        header.extend(struct.pack("!H", payload_len))
    else:
        header.append(127)
        header.extend(struct.pack("!Q", payload_len))
        
    try:
        sock.sendall(header + payload)
    except Exception:
        pass

# ----------------- Background Task Runner Thread -----------------
def task_runner_loop() -> None:
    home = Path(os.environ.get("ARENA_AGENT_HOME", os.path.expanduser("~/arena-agent")))
    inbox = home / "queue" / "inbox"
    running = home / "queue" / "running"
    done = home / "queue" / "done"
    failed = home / "queue" / "failed"
    
    while True:
        try:
            time.sleep(5)
            if not inbox.exists():
                continue
            for task_file in sorted(inbox.glob("*.json")):
                print(f"[TASK RUNNER] Found task: {task_file.name}")
                # Move to running
                running.mkdir(parents=True, exist_ok=True)
                run_file = running / task_file.name
                if run_file.exists(): run_file.unlink()
                os.rename(str(task_file), str(run_file))
                
                try:
                    task = json.loads(run_file.read_text(encoding="utf-8"))
                    cmd = task.get("cmd", "")
                    
                    t0 = time.time()
                    res = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=task.get("timeout", 300))
                    duration = round(time.time() - t0, 3)
                    
                    task.update({
                        "state": "done" if res.returncode == 0 else "failed",
                        "exit_code": res.returncode,
                        "stdout": res.stdout,
                        "stderr": res.stderr,
                        "duration_sec": duration,
                        "finished_at": utc_now()
                    })
                    
                    # Write to done/failed
                    target_dir = done if res.returncode == 0 else failed
                    target_dir.mkdir(parents=True, exist_ok=True)
                    target_file = target_dir / task_file.name
                    target_file.write_text(json.dumps(task, indent=2, ensure_ascii=False), encoding="utf-8")
                    
                    # Play a success beep on the host!
                    try:
                        import winsound
                        winsound.Beep(523, 120)
                    except: pass
                except Exception as e:
                    # Move to failed
                    failed.mkdir(parents=True, exist_ok=True)
                    fail_file = failed / task_file.name
                    fail_file.write_text(json.dumps({"error": str(e), "state": "failed"}, indent=2), encoding="utf-8")
                finally:
                    if run_file.exists(): run_file.unlink()
        except Exception:
            pass

# Start task runner as daemon thread
threading.Thread(target=task_runner_loop, daemon=True).start()

# ----------------- HTTP Handler -----------------
class BridgeHandler(BaseHTTPRequestHandler):
    server_version = f"ArenaLocalBridge/{VERSION}"

    def log_message(self, fmt: str, *args: Any) -> None:
        sys.stderr.write("[%s] %s\n" % (utc_now(), fmt % args))

    @property
    def cfg(self):
        return self.server.cfg

    def send_json(self, obj: Any, status: int = 200) -> None:
        code, data = json_bytes(obj, status)
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Arena-Token, Authorization")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def unauthorized(self) -> None:
        self.send_json({"ok": False, "error": "unauthorized"}, 401)

    def check_auth(self) -> bool:
        auth_header = self.headers.get("Authorization", "")
        gateway_token = self.headers.get("X-Arena-Token", "")
        token = self.cfg["token"]
        return auth_header == f"Bearer {token}" or gateway_token == token

    def read_json(self) -> dict[str, Any] | None:
        try:
            length = int(self.headers.get("Content-Length", "0") or "0")
        except ValueError:
            self.send_json({"ok": False, "error": "invalid content-length"}, 400); return None
        if length > MAX_BODY:
            self.send_json({"ok": False, "error": "body too large"}, 413); return None
        raw = self.rfile.read(length) if length else b"{}"
        try:
            data = json.loads(raw.decode("utf-8"))
            if not isinstance(data, dict):
                raise ValueError("JSON must be object")
            return data
        except Exception as e:
            self.send_json({"ok": False, "error": f"invalid json: {e}"}, 400); return None

    def common_status(self) -> dict[str, Any]:
        return {
            "ok": True,
            "service": "arena-local-bridge",
            "version": VERSION,
            "host": socket.gethostname(),
            "platform": platform.platform(),
            "python": sys.version.split()[0],
            "profile": self.cfg["profile"],
            "root": str(self.cfg["root"]),
            "auth_required_for_exec": True,
            "active_exec": self.cfg["active_exec"],
            "max_concurrent": self.cfg["max_concurrent"],
            "audit": str(AUDIT),
        }

    def do_OPTIONS(self) -> None:
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Arena-Token, Authorization")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.end_headers()

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path
        
        # 1. WebSocket Upgrade Handler
        if path == "/ws" and self.headers.get("Upgrade", "").lower() == "websocket":
            # Handshake Accept key
            key = self.headers.get("Sec-WebSocket-Key")
            accept_raw = key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
            accept_key = base64.b64encode(hashlib.sha1(accept_raw.encode()).digest()).decode()
            
            self.send_response(101)
            self.send_header("Upgrade", "websocket")
            self.send_header("Connection", "Upgrade")
            self.send_header("Sec-WebSocket-Accept", accept_key)
            self.end_headers()
            
            # Hijack the socket and pass to WebSocket loop!
            sock = self.connection
            handle_websocket_connection(sock, self)
            return
            
        # 2. Web Gateway Tools List
        if path == "/gateway/tools" or path == "/tools":
            if not self.check_auth(): return self.unauthorized()
            self.send_json({"ok": True, "whitelist_prefixes": list(WHITELIST_PREFIXES), "mcp_tools": TOOLS})
            return
            
        if path == "/":
            self.send_json({
                "ok": True,
                "service": "arena-local-bridge",
                "version": VERSION,
                "endpoints": ["/health", "/v1/info", "/v1/status", "/v1/audit?lines=100", "POST /v1/exec", "POST /v1/upload?path=", "GET /v1/download?path=", "/mcp", "/ws", "/gateway/tools", "/gateway/run"],
                "auth_required_for_exec": True,
            })
            return
            
        if path == "/health":
            s = self.common_status()
            for k in ["audit", "active_exec", "max_concurrent", "python"]:
                s.pop(k, None)
            self.send_json(s)
            return
            
        if path in {"/v1/info", "/v1/status"}:
            if not self.check_auth(): self.unauthorized(); return
            self.send_json(self.common_status())
            return
            
        if path == "/v1/download":
            if not self.check_auth(): self.unauthorized(); return
            qs = parse_qs(parsed.query)
            target = qs.get("path", [""])[0]
            if not target:
                self.send_json({"ok": False, "error": "missing path"}, 400); return
            target_path = Path(target).expanduser()
            if not target_path.is_absolute():
                target_path = self.cfg["root"] / target_path
            if not target_path.exists() or not target_path.is_file():
                self.send_json({"ok": False, "error": "file not found"}, 404); return
            
            try:
                size = target_path.stat().st_size
                self.send_response(200)
                self.send_header("Content-Type", "application/octet-stream")
                self.send_header("Content-Length", str(size))
                self.send_header("Content-Disposition", f'attachment; filename="{target_path.name}"')
                self.end_headers()
                with target_path.open("rb") as f:
                    import shutil
                    shutil.copyfileobj(f, self.wfile)
                audit({"type": "file_download", "path": str(target_path), "size": size})
            except Exception as e:
                self.send_json({"ok": False, "error": repr(e)}, 500)
            return

        if path == "/v1/audit":
            if not self.check_auth(): self.unauthorized(); return
            qs = parse_qs(parsed.query)
            try: lines = int(qs.get("lines", ["100"])[0])
            except ValueError: lines = 100
            self.send_json({"ok": True, "audit": read_tail(AUDIT, lines)})
            return

        if path == "/gui":
            html_path = self.cfg["root"] / "arena-agent/dashboard/index.html"
            if html_path.exists():
                html = html_path.read_text(encoding='utf-8')
                html = html.replace("{{TOKEN}}", self.cfg["token"])
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.end_headers()
                self.wfile.write(html.encode('utf-8'))
            else:
                self.send_response(404)
                self.end_headers()
                self.wfile.write(b"Dashboard index.html not found.")
            return
            
        self.send_response(404)
        self.end_headers()

    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path
        
        # 1. MCP HTTP SSE endpoint
        if path == "/mcp":
            # Handled directly on port 8765
            data = self.read_json()
            if data is None: return
            resp = handle_rpc(data)
            self.send_json(resp)
            return
            
        # 2. Web Gateway Run Whitelist command
        if path == "/gateway/run" or path == "/run":
            if not self.check_auth(): return self.unauthorized()
            data = self.read_json()
            if data is None: return
            cmd = (data.get("command") or "").strip()
            if not cmd: return self.send_json({"ok": False, "error": "missing command"}, 400)
            
            # Verify whitelist
            if not any(cmd.startswith(p) for p in WHITELIST_PREFIXES):
                return self.send_json({"ok": False, "error": "command not in whitelist"}, 403)
                
            try:
                p = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=int(data.get("timeout", 60)))
                self.send_json({"ok": p.returncode == 0, "exit": p.returncode, "stdout": p.stdout, "stderr": p.stderr})
            except Exception as e:
                self.send_json({"ok": False, "error": str(e)}, 500)
            return
            
        # 3. Standard /v1/exec endpoint
        if path != "/v1/exec":
            self.send_json({"ok": False, "error": "not found"}, 404); return
        if not self.check_auth():
            self.unauthorized(); return
        data = self.read_json()
        if data is None: return
        request_id = str(data.get("request_id") or uuid.uuid4())
        cmd = str(data.get("cmd", "")).strip()
        if not cmd:
            self.send_json({"ok": False, "error": "missing cmd", "request_id": request_id}, 400); return

        reason = blocked_reason(cmd)
        if reason:
            audit({"type": "exec_blocked", "request_id": request_id, "cmd": cmd, "reason": reason, "client": self.client_address[0]})
            self.send_json({"ok": False, "error": reason, "request_id": request_id}, 403); return

        profile = self.cfg["profile"]
        fw = first_word(cmd)
        if profile == "cautious" and fw not in CAUTIOUS_ALLOW:
            reason = f"command '{fw}' is not in cautious allowlist"
            audit({"type": "exec_blocked", "request_id": request_id, "cmd": cmd, "reason": reason, "client": self.client_address[0]})
            self.send_json({"ok": False, "error": reason, "request_id": request_id}, 403); return

        root: Path = self.cfg["root"]
        cwd_raw = str(data.get("cwd") or root)
        cwd = Path(cwd_raw).expanduser()
        if not cwd.is_absolute(): cwd = root / cwd
        if not self.cfg["allow_any_cwd"] and not under_root(cwd, root):
            self.send_json({"ok": False, "error": f"cwd must be under root {root}", "request_id": request_id}, 403); return
        if not cwd.exists() or not cwd.is_dir():
            self.send_json({"ok": False, "error": f"cwd does not exist or is not a directory: {cwd}", "request_id": request_id}, 400); return

        timeout = min(int(data.get("timeout", self.cfg["timeout"])), self.cfg["max_timeout"])
        max_output = min(int(data.get("max_output", DEFAULT_MAX_OUTPUT)), self.cfg["max_output"])
        env_extra = data.get("env") if isinstance(data.get("env"), dict) else {}
        env = os.environ.copy(); env.update({str(k): str(v) for k, v in env_extra.items()})

        sem: threading.BoundedSemaphore = self.cfg["semaphore"]
        if not sem.acquire(blocking=False):
            self.send_json({"ok": False, "error": "too many concurrent exec requests", "request_id": request_id}, 429); return

        self.cfg["active_exec"] += 1
        RUN_DIR.mkdir(parents=True, exist_ok=True)
        run_dir = Path(tempfile.mkdtemp(prefix=f"{request_id}-", dir=str(RUN_DIR)))
        stdout_path, stderr_path = run_dir / "stdout.txt", run_dir / "stderr.txt"
        audit({"type": "exec_start", "request_id": request_id, "cmd": cmd, "cwd": str(cwd), "timeout": timeout, "client": self.client_address[0]})
        t0 = time.time(); timed_out = False; proc = None
        try:
            with stdout_path.open("wb") as out, stderr_path.open("wb") as err:
                popen_kwargs: dict[str, Any] = dict(shell=True, cwd=str(cwd), env=env, stdout=out, stderr=err)
                
                def preexec():
                    if os.name == "posix":
                        os.setsid()
                if sys.platform != "win32": popen_kwargs["preexec_fn"] = preexec

                proc = subprocess.Popen(cmd, **popen_kwargs)
                ACTIVE_PROCESSES[request_id] = {"cmd": cmd, "proc": proc, "start": time.time()}

                try:
                    exit_code = proc.wait(timeout=timeout)
                except subprocess.TimeoutExpired:
                    timed_out = True
                    if os.name == "posix":
                        try: os.killpg(proc.pid, signal.SIGTERM)
                        except Exception: pass
                    else:
                        try: proc.kill()
                        except Exception: pass
                    exit_code = proc.wait(timeout=5) if proc.poll() is None else proc.returncode
            duration = round(time.time() - t0, 3)
            stdout, trunc_out, stdout_bytes = read_limited(stdout_path, max_output)
            stderr, trunc_err, stderr_bytes = read_limited(stderr_path, max_output)
            truncated = trunc_out or trunc_err
            ok = (not timed_out) and exit_code == 0
            event_type = "exec_timeout" if timed_out else "exec_done"
            audit({"type": event_type, "request_id": request_id, "cmd": cmd, "exit_code": exit_code, "duration": duration, "truncated": truncated, "stdout_bytes": stdout_bytes, "stderr_bytes": stderr_bytes})
            self.send_json({
                "ok": ok,
                "request_id": request_id,
                "exit_code": exit_code,
                "duration_sec": duration,
                "cwd": str(cwd),
                "stdout": stdout,
                "stderr": stderr,
                "truncated": truncated,
                "stdout_bytes": stdout_bytes,
                "stderr_bytes": stderr_bytes,
                "error": f"timeout after {timeout}s" if timed_out else None,
            }, 408 if timed_out else 200)
        except Exception as e:
            duration = round(time.time() - t0, 3)
            audit({"type": "exec_error", "request_id": request_id, "cmd": cmd, "duration": duration, "error": repr(e)})
            self.send_json({"ok": False, "request_id": request_id, "error": repr(e), "duration_sec": duration}, 500)
        
        finally:
            ACTIVE_PROCESSES.pop(request_id, None)
            self.cfg["active_exec"] -= 1
            sem.release()
            try:
                for p in [stdout_path, stderr_path]:
                    if p.exists(): p.unlink()
                run_dir.rmdir()
            except Exception:
                pass

def read_tail(path: Path, lines: int = 100) -> list[str]:
    if not path.exists():
        return []
    lines = max(1, min(lines, 1000))
    return path.read_text(encoding="utf-8", errors="replace").splitlines()[-lines:]

def json_bytes(obj: Any, status: int = 200) -> tuple[int, bytes]:
    return status, (json.dumps(obj, ensure_ascii=False, indent=2) + "\n").encode("utf-8")

def serve(args: argparse.Namespace) -> None:
    token = args.token or os.environ.get("ARENA_LOCAL_BRIDGE_TOKEN")
    if not token:
        print("No token provided.", file=sys.stderr)
        raise SystemExit(2)
    root = Path(args.root).expanduser().resolve(); root.mkdir(parents=True, exist_ok=True)
    cfg = {
        "token": token,
        "profile": args.profile,
        "root": root,
        "allow_any_cwd": args.allow_any_cwd,
        "timeout": args.timeout,
        "max_timeout": args.max_timeout,
        "max_output": args.max_output,
        "max_concurrent": args.max_concurrent,
        "semaphore": threading.BoundedSemaphore(args.max_concurrent),
        "active_exec": 0,
    }
    server = BridgeHTTPServer((args.bind, args.port), BridgeHandler)
    server.cfg = cfg
    print(f"Arena Local Bridge Unified v{VERSION} on http://{args.bind}:{args.port} (auth={bool(token)})", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        server.server_close()

def main() -> None:
    p = argparse.ArgumentParser(description="Arena Local Bridge")
    sub = p.add_subparsers(dest="cmd", required=True)
    sp = sub.add_parser("serve", help="run local command bridge")
    sp.add_argument("--bind", default="127.0.0.1")
    sp.add_argument("--port", type=int, default=8765)
    sp.add_argument("--token")
    sp.add_argument("--root", default=str(Path.home()))
    sp.add_argument("--allow-any-cwd", action="store_true")
    sp.add_argument("--profile", choices=["cautious", "owner-shell"], default="cautious")
    sp.add_argument("--timeout", type=int, default=60)
    sp.add_argument("--max-timeout", type=int, default=600)
    sp.add_argument("--max-output", type=int, default=DEFAULT_MAX_OUTPUT)
    sp.add_argument("--max-concurrent", type=int, default=DEFAULT_MAX_CONCURRENT)
    sp.set_defaults(func=serve)
    args = p.parse_args(); args.func(args)

if __name__ == "__main__":
    main()
