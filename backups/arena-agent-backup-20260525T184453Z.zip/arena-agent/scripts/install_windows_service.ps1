# Arena Local Agent  Windows Installer v5.9 (Final Complete Release)

#  5   Task Scheduler   /  ,

#  Node.js,  ,  agentctl   PATH   bat-.

#  100%    v0.4.0  Windows:      .

#     (clean slate),    ,   .

#    Python- (requests, beautifulsoup4, httpx)     HTTP-.

#    PowerShell 5.1.

# :    powershell -ExecutionPolicy Bypass -File install_windows_service.ps1

# :  powershell -ExecutionPolicy Bypass -File install_windows_service.ps1 -Uninstall

# : powershell -ExecutionPolicy Bypass -File install_windows_service.ps1 -Update

param([switch]$Uninstall, [switch]$Update)

$ErrorActionPreference = "Stop"

$BridgePath = Join-Path $env:USERPROFILE "arena-local-bridge"

$AgentPath  = Join-Path $env:USERPROFILE "arena-agent"

$TokenPath  = Join-Path $BridgePath "token.txt"

# 100% WINDOWS COMPATIBLE ARGUMENTS (v5.9):

$Tasks = @(

@{ Name="ArenaLocalBridge"; Script="$BridgePath\local_bridge.py";

Args="serve --root `"$env:USERPROFILE`" --profile owner-shell";

UsesToken=$true; Port=8765 }

@{ Name="ArenaMcpStream"; Script="$AgentPath\scripts\mcp_stream_server.py";

Args="--host 127.0.0.1 --port 8767"; UsesToken=$false; Port=8767 }

@{ Name="ArenaMcpWs"; Script="$AgentPath\scripts\mcp_ws_server.py";

Args="--host 127.0.0.1 --port 8768"; UsesToken=$false; Port=8768 }

@{ Name="ArenaTaskRunner"; Script="$AgentPath\bin\agentctl";

Args="task-watch --interval 5 --max 1"; UsesToken=$false; Port=$null }

@{ Name="ArenaWebGateway"; Script="$AgentPath\bin\web_gateway.py";

Args="--host 127.0.0.1 --port 8769"; UsesToken=$false; Port=8769 }

)

# ------------------- Helpers -------------------

function Ensure-NodeJS {

$node = Get-Command node -ErrorAction SilentlyContinue

if ($node) { return $node.Source }

Write-Host "=== Node.js not found. Installing LTS silently... ===" -ForegroundColor Yellow

$msiUrl = "https://nodejs.org/dist/v20.15.1/node-v20.15.1-x64.msi"

$msiFile = Join-Path $env:TEMP "node-lts.msi"

try {

Invoke-WebRequest -Uri $msiUrl -OutFile $msiFile -UseBasicParsing

Start-Process msiexec.exe -ArgumentList "/i `"$msiFile`" /qn ADDLOCAL=ALL" -Wait -NoNewWindow

Remove-Item $msiFile -Force

} catch {

Write-Warning "Automatic Node.js installation failed. Please install manually from https://nodejs.org/ and re-run."

return $null

}

# Refresh PATH

$env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")

$node = Get-Command node -ErrorAction SilentlyContinue

if ($node) {

Write-Host "[OK] Node.js installed at $($node.Source)" -ForegroundColor Green

return $node.Source

}

return $null

}

function Ensure-Python {

Write-Host "Searching for a working Python installation..." -ForegroundColor Cyan

$candidates = @()

# 1. Try python in current PATH

$py = Get-Command python -ErrorAction SilentlyContinue

if ($py) { $candidates += $py.Source }

$py3 = Get-Command python3 -ErrorAction SilentlyContinue

if ($py3) { $candidates += $py3.Source }

# 2. Try standard local AppData Programs folder (where official python.org installer installs Python)

$localPrograms = Join-Path $env:LOCALAPPDATA "Programs\Python"

if (Test-Path $localPrograms) {

$foundLocal = Get-ChildItem -Path $localPrograms -Filter "python.exe" -Recurse -ErrorAction SilentlyContinue | Select-Object -ExpandProperty FullName

if ($foundLocal) { $candidates += $foundLocal }

}

# 3. Try Program Files standard python paths

$progFiles = "C:\Program Files"

if (Test-Path $progFiles) {

$foundGlobal = Get-ChildItem -Path "$progFiles\Python*" -Filter "python.exe" -Recurse -ErrorAction SilentlyContinue | Select-Object -ExpandProperty FullName

if ($foundGlobal) { $candidates += $foundGlobal }

}

# 4. Verify each candidate by actually executing it (ignoring broken wrappers like PyManager or Microsoft Store stub)

foreach ($c in $candidates) {

if (-not (Test-Path $c)) { continue }

try {

# Execute with --version to verify it is a real, working Python interpreter

$pinfo = Start-Process -FilePath $c -ArgumentList "--version" -NoNewWindow -PassThru -RedirectStandardOutput "$env:TEMP\py_test_out.txt" -RedirectStandardError "$env:TEMP\py_test_err.txt" -Wait

if ($pinfo.ExitCode -eq 0) {

# Working python interpreter found!

Write-Host "[OK] Verified working Python: $c" -ForegroundColor Green

# Clean up test files

Remove-Item "$env:TEMP\py_test_out.txt" -ErrorAction SilentlyContinue | Out-Null

Remove-Item "$env:TEMP\py_test_err.txt" -ErrorAction SilentlyContinue | Out-Null

return $c

}

} catch {

# Execution failed or threw an exception, skip this candidate

}

}

# If we reached here, no working Python was found

Write-Error "No working Python interpreter found in your system. Please install official Python 3.10+ from https://python.org/downloads/ and tick 'Add python.exe to PATH' during installation."

exit 1

}

function Generate-Token {

if (-not (Test-Path $TokenPath)) {

$bytes = New-Object byte[] 32

try {

[Security.Cryptography.RandomNumberGenerator]::Fill($bytes)

} catch {

# Bulletproof fallback for older .NET versions

$rng = New-Object System.Security.Cryptography.RNGCryptoServiceProvider

$rng.GetBytes($bytes)

}

$token = [Convert]::ToBase64String($bytes).TrimEnd('=').Replace('+','-').Replace('/','_')

Set-Content -Path $TokenPath -Value $token -NoNewline -Encoding ASCII

Write-Host "[OK] generated token -> $TokenPath" -ForegroundColor Green

} else {

# Ensure existing token is not empty or corrupted (UTF-16 BOM cleanup)

$data = [System.IO.File]::ReadAllBytes($TokenPath)

$token = [System.Text.Encoding]::UTF8.GetString($data).Trim()

if ($token -like "*?*" -or $token.Length -lt 10) {

# Re-generate clean token if old one is corrupt

Remove-Item $TokenPath -Force -ErrorAction SilentlyContinue | Out-Null

$bytes = New-Object byte[] 32

[System.Security.Cryptography.RNGCryptoServiceProvider]::new().GetBytes($bytes)

$token = [Convert]::ToBase64String($bytes).TrimEnd('=').Replace('+','-').Replace('/','_')

Set-Content -Path $TokenPath -Value $token -NoNewline -Encoding ASCII

Write-Host "[OK] Re-generated corrupted token -> $TokenPath" -ForegroundColor Green

}

}

}

function Stop-AllTasks {

foreach ($t in $Tasks) {

Stop-ScheduledTask -TaskName $t.Name -ErrorAction SilentlyContinue | Out-Null

Write-Host "[OK] stopped $($t.Name)"

if ($t.Port) {

$conn = Get-NetTCPConnection -LocalPort $t.Port -ErrorAction SilentlyContinue

if ($conn) {

foreach ($c in $conn) {

Stop-Process -Id $c.OwningProcess -Force -ErrorAction SilentlyContinue | Out-Null

Write-Host "  - Terminated active process $($c.OwningProcess) holding port $($t.Port)" -ForegroundColor Yellow

}

}

}

}

# Force-kill orphaned Python processes (to free up file locks like audit.jsonl)

$currentPid = $PID

Get-Process -Name python -ErrorAction SilentlyContinue | Where-Object { $_.Id -ne $currentPid } | ForEach-Object {

Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue | Out-Null

Write-Host "  - Force-killed orphaned python process: $($_.Id)" -ForegroundColor Yellow

}

}

function Start-AllTasks {

foreach ($t in $Tasks) {

Start-ScheduledTask -TaskName $t.Name -ErrorAction SilentlyContinue | Out-Null

Write-Host "[OK] started $($t.Name)"

}

}

function Remove-AllTasks {

foreach ($t in $Tasks) {

Unregister-ScheduledTask -TaskName $t.Name -Confirm:$false -ErrorAction SilentlyContinue

Write-Host "[OK] removed $($t.Name)"

}

}

function Create-Tasks {

foreach ($t in $Tasks) {

if (-not (Test-Path $t.Script)) {

Write-Warning "Skipping $($t.Name): script not found at $($t.Script). Copy files and re-run."

continue

}

$startPs1 = Join-Path $BridgePath ("start_" + $t.Name + ".ps1")

$body = @()

$body += '$ErrorActionPreference = "Continue"'

$body += 'Set-Location "' + $BridgePath + '"'

$ArgsLine = $t.Args

if ($t.UsesToken) {

$data = [System.IO.File]::ReadAllBytes($TokenPath)

$TokenString = [System.Text.Encoding]::UTF8.GetString($data).Trim()

$ArgsLine += " --token `"$TokenString`""

}

$logFile = Join-Path $AgentPath "logs\$($t.Name).log"

# Run with "-u" unbuffered flag for direct and unbuffered log output

        # Redirect using cmd.exe /c to ensure logs are written in standard clean ANSI/UTF-8 (eliminates PowerShell UTF-16 spacing issue)
        $body += '& "' + $PyExe + '" -u "' + $t.Script + '" ' + $ArgsLine + ' *>> "' + $logFile + '"'

Set-Content -Path $startPs1 -Value ($body -join "`r`n") -Encoding UTF8

$Action    = New-ScheduledTaskAction -Execute "powershell.exe" -Argument ("-WindowStyle Hidden -NoProfile -ExecutionPolicy Bypass -File `"" + $startPs1 + "`"")

$Trigger   = New-ScheduledTaskTrigger -AtLogOn

$Principal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive -RunLevel Limited

$Settings  = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1)

Register-ScheduledTask -TaskName $t.Name -Action $Action -Trigger $Trigger -Principal $Principal -Settings $Settings -Force | Out-Null

Write-Host "[OK] registered $($t.Name) (port $($t.Port))"

}

}

# ------------------- Main flow -------------------

if ($Uninstall) {

Stop-AllTasks

Remove-AllTasks

# Remove bin from User PATH if present

$UserPath = [System.Environment]::GetEnvironmentVariable("Path", "User")

$BinPath = Join-Path $AgentPath "bin"

if ($UserPath -like "*$BinPath*") {

# Clean up path safely

$NewPath = ($UserPath -split ";" | Where-Object { $_ -ne $BinPath }) -join ";"

[System.Environment]::SetEnvironmentVariable("Path", $NewPath, "User")

Write-Host "[OK] Removed $BinPath from User PATH." -ForegroundColor Green

}

Write-Host "`n=== UNINSTALL COMPLETE ===" -ForegroundColor Green

return

}

# Ensure dirs (v5.1: Added "$AgentPath\logs" to ensure the logs folder exists)

New-Item -ItemType Directory -Force -Path $BridgePath, $AgentPath, "$AgentPath\scripts", "$AgentPath\bin", "$AgentPath\logs" | Out-Null

# Python

$PyExe = Ensure-Python

Write-Host "[OK] using Python: $PyExe"

# Node.js (for MCP plugins)

$null = Ensure-NodeJS

# Token

Generate-Token

# DEPENDENCIES INSTALLATION:

# Install required Python packages (httpx, requests, beautifulsoup4) so that Web Recon and Fallback Browser work flawlessly on Windows!

Write-Host "Installing/Updating required Python packages (httpx, requests, beautifulsoup4) via pip..." -ForegroundColor Cyan

try {

Start-Process -FilePath $PyExe -ArgumentList "-m pip install --quiet --upgrade httpx requests beautifulsoup4" -NoNewWindow -Wait

Write-Host "[OK] Python packages ready." -ForegroundColor Green

} catch {

Write-Warning "Could not install python dependencies automatically. Please run manually: pip install httpx requests beautifulsoup4"

}

# Create agentctl.bat wrapper to run Python-native agentctl correctly on Windows

$AgentBin = Join-Path $AgentPath "bin"

$AgentctlBat = Join-Path $AgentBin "agentctl.bat"

$BatContent = "@echo off`r`n`"$PyExe`" `"%~dp0agentctl`" %*"

Set-Content -Path $AgentctlBat -Value $BatContent -Encoding ASCII

Write-Host "[OK] created Windows executable wrapper: $AgentctlBat" -ForegroundColor Green

# Add bin path to User persistent PATH so typing "agentctl" works out-of-the-box

$UserPath = [System.Environment]::GetEnvironmentVariable("Path", "User")

if ($UserPath -notlike "*$AgentBin*") {

$Separator = if ($UserPath.Length -eq 0 -or $UserPath.EndsWith(";")) { "" } else { ";" }

[System.Environment]::SetEnvironmentVariable("Path", $UserPath + $Separator + $AgentBin, "User")

Write-Host "[OK] Added $AgentBin to User persistent PATH. (Please restart any open terminal windows to apply)" -ForegroundColor Green

}

# CRITICAL SYSTEMD/TASK SCHEDULER SYNC FIX (v5.2):

# We ALWAYS stop and completely unregister old tasks before creating and starting the new ones.

# This prevents Task Scheduler from keeping zombie states and refusing to launch updated tasks.

Write-Host "`n=== CLEAN SLATE: Stopping and removing old tasks... ===" -ForegroundColor Yellow

Stop-AllTasks

Remove-AllTasks

# Re-create and restart everything fresh

Create-Tasks

Start-AllTasks

# Check for Git (v5.9)

$GitCmd = Get-Command git -ErrorAction SilentlyContinue

if (-not $GitCmd) {

Write-Host "`n[NOTICE] Git was not found on your system." -ForegroundColor Yellow

Write-Host "While Arena Agent is fully operational in folder-only mode," -ForegroundColor Yellow

Write-Host "some advanced project-management commands ('agentctl proj') require Git." -ForegroundColor Yellow

Write-Host "If you wish to use Git, you can install it easily by running this command in CMD/PowerShell:" -ForegroundColor Yellow

Write-Host "  winget install Git.Git" -ForegroundColor Cyan

}

# Read Token Value and Find Tailscale URL on-the-fly (v6.2)

$TokenVal = (Get-Content -Path $TokenPath -Raw).Trim()

$FunnelUrl = "Not enabled"

if (Get-Command tailscale -ErrorAction SilentlyContinue) {

    $statusArray = tailscale serve status 2>$null

    if ($statusArray) {

        $statusString = $statusArray -join "`r`n"
        if ($statusString -match "(https://[^\s]+)") {
            $FunnelUrl = $Matches[1]
        }

}

}

Write-Host ""

Write-Host "=== INSTALLATION COMPLETE ===" -ForegroundColor Green

Write-Host "Tasks registered and started. They will auto-start at every logon."

Write-Host ""

Write-Host "[TOKEN] YOUR ACCESS TOKEN:  $TokenVal" -ForegroundColor Cyan

Write-Host "[URL] YOUR TAILSCALE URL: $FunnelUrl" -ForegroundColor Cyan

Write-Host ""

Write-Host "To expose to internet (if not enabled):  tailscale funnel --bg 8765"

Write-Host "To open local dashboard:                 http://127.0.0.1:8765/gui"

Write-Host "To update later:                         run update.bat in $AgentPath"

Write-Host "=============================="