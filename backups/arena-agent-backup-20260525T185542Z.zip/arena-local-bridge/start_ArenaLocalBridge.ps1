﻿$ErrorActionPreference = "Continue"
Set-Location "C:\Users\Ivan\arena-local-bridge"
& "C:\Users\Ivan\AppData\Local\Programs\Python\Python314\python.exe" -u "C:\Users\Ivan\arena-local-bridge\local_bridge.py" serve --root "C:\Users\Ivan" --profile owner-shell --token "6IKA1nXj8zvJuuSfKaZ4c9QSdr_Y_WQuW7XSnboRQZA" *>> "C:\Users\Ivan\arena-agent\logs\ArenaLocalBridge.log"
