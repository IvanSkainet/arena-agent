﻿$ErrorActionPreference = "Continue"
Set-Location "C:\Users\Ivan\arena-local-bridge"
& "C:\Users\Ivan\AppData\Local\Programs\Python\Python314\python.exe" -u "C:\Users\Ivan\arena-local-bridge\local_bridge.py" serve --root "C:\Users\Ivan" --profile owner-shell --token "cviI5-XU4phduk1NggdKhsUNnqhE6UfStPWJEK6s1pQ" *>> "C:\Users\Ivan\arena-agent\logs\ArenaLocalBridge.log"
