﻿$ErrorActionPreference = "Continue"
Set-Location "C:\Users\Ivan\arena-local-bridge"
& "C:\Users\Ivan\AppData\Local\Programs\Python\Python314\python.exe" -u "C:\Users\Ivan\arena-local-bridge\local_bridge.py" serve --root "C:\Users\Ivan" --profile owner-shell --token "ra6aGZeac3urB8l1JXCPpLCUnGhPo0LX7Ds4b3Eyt3E" *>> "C:\Users\Ivan\arena-agent\logs\ArenaLocalBridge.log"
