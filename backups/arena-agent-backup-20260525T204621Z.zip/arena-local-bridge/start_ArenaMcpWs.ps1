﻿$ErrorActionPreference = "Continue"
Set-Location "C:\Users\Ivan\arena-local-bridge"
& "C:\Users\Ivan\AppData\Local\Programs\Python\Python314\python.exe" -u "C:\Users\Ivan\arena-agent\scripts\mcp_ws_server.py" --host 127.0.0.1 --port 8768 *>> "C:\Users\Ivan\arena-agent\logs\ArenaMcpWs.log"
