﻿$ErrorActionPreference = "Continue"
Set-Location "C:\Users\Ivan\arena-local-bridge"
& "C:\Users\Ivan\AppData\Local\Programs\Python\Python314\python.exe" -u "C:\Users\Ivan\arena-agent\bin\agentctl" task-watch --interval 5 --max 1 *>> "C:\Users\Ivan\arena-agent\logs\ArenaTaskRunner.log"
