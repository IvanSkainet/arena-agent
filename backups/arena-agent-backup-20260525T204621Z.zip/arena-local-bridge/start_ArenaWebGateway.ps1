﻿$ErrorActionPreference = "Continue"
Set-Location "C:\Users\Ivan\arena-local-bridge"
& "C:\Users\Ivan\AppData\Local\Programs\Python\Python314\python.exe" -u "C:\Users\Ivan\arena-agent\bin\web_gateway.py" --host 127.0.0.1 --port 8769 *>> "C:\Users\Ivan\arena-agent\logs\ArenaWebGateway.log"
