#!/usr/bin/env python3
"""
Arena Local Bridge v0.2

Explicit user-run/user-service HTTP bridge for executing commands on the owner's
machine through a temporary/controlled transport such as Tailscale Funnel.

Security posture:
- binds to 127.0.0.1 by default;
- requires bearer token for exec/info/status/audit endpoints;
- logs every command to ~/.arena-local-bridge/audit.jsonl;
- owner-shell mode is available, but high-risk destructive patterns remain blocked;
- stdout/stderr are captured to temporary files and truncated on read to avoid
  retaining very large command output in the bridge process.
"""
from __future__ import annotations
import sys
if sys.platform == "win32":
    class MockResource:
        RLIMIT_NOFILE = 0
        def getrlimit(self, *args, **kwargs): return (1024, 1024)
        def setrlimit(self, *args, **kwargs): pass
    sys.modules["resource"] = MockResource()


import argparse
import base64
import hashlib
import json
import os
import platform
import re
import secrets
import shlex
import signal
import socket
import resource
import subprocess
import sys
import tempfile
import threading
import time
import uuid
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

VERSION = "0.4.0"
AUDIT_CMD_LIMIT = 4000
APP_DIR = Path.home() / ".arena-local-bridge"
AUDIT = APP_DIR / "audit.jsonl"
RUN_DIR = APP_DIR / "runs"
MAX_BODY = 1024 * 1024
DEFAULT_MAX_OUTPUT = 2 * 1024 * 1024
DEFAULT_MAX_CONCURRENT = 3
ACTIVE_PROCESSES = {}

CAUTIOUS_ALLOW = {
    "pwd", "ls", "dir", "tree", "find", "fd", "rg", "grep", "cat", "type", "head", "tail", "wc",
    "whoami", "hostname", "uname", "ver", "systeminfo", "ipconfig", "ifconfig", "ip", "ss", "netstat",
    "python", "python3", "py", "node", "npm", "pnpm", "yarn", "bun", "deno", "uv",
    "git", "gh", "go", "cargo", "rustc", "java", "javac", "mvn", "gradle", "dotnet",
    "pacman", "paru", "yay", "winget", "choco", "scoop", "pip", "pip3",
    "bash", "sh", "zsh", "fish", "pwsh", "powershell", "cmd",
}

BLOCK_PATTERNS = [
    r"\brm\s+-[^\n]*r[^\n]*f[^\n]*(/|~|\*)",
    r"\bsudo\b",
    r"\bsu\b",
    r"\bmkfs(\.|\s|$)",
    r"\bdd\s+.*\bof\s*=\s*/dev/",
    r"\bshutdown\b",
    r"\breboot\b",
    r"\bhalt\b",
    r"\bpoweroff\b",
    r"\bdiskpart\b",
    r"\bformat\s+[A-Za-z]:",
    r"\bbcdedit\b",
    r"\breg\s+delete\b",
    r"\btakeown\b",
    r"\bicacls\b.*\b/grant\b",
    r"\bchmod\s+-R\s+777\s+(/|~)",
    r"(curl|wget).*(\||>)\s*(sh|bash|zsh|fish|pwsh|powershell)",
    r"powershell(\.exe)?\s+.*-(enc|encodedcommand)\b",
]

audit_lock = threading.Lock()


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")



def clean_run_dir():
    try:
        import shutil
        if RUN_DIR.exists():
            shutil.rmtree(RUN_DIR)
        RUN_DIR.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass

def b64_token(nbytes: int = 32) -> str:
    return base64.urlsafe_b64encode(secrets.token_bytes(nbytes)).decode().rstrip("=")


def sanitize_audit_event(event: dict[str, Any]) -> dict[str, Any]:
    """Keep audit useful but bounded; avoid huge base64/scripts bloating logs."""
    out: dict[str, Any] = {}
    for k, v in event.items():
        lk = k.lower()
        if "token" in lk or "authorization" in lk or "password" in lk or "secret" in lk:
            out[k] = "<redacted>"
            continue
        if k == "cmd" and isinstance(v, str):
            out["cmd_len"] = len(v)
            out["cmd_sha256"] = hashlib.sha256(v.encode("utf-8", "replace")).hexdigest()
            if len(v) > AUDIT_CMD_LIMIT:
                out[k] = v[:AUDIT_CMD_LIMIT] + f"\n...[truncated {len(v) - AUDIT_CMD_LIMIT} chars; sha256={out['cmd_sha256']}]"
                out["cmd_truncated"] = True
            else:
                out[k] = v
                out["cmd_truncated"] = False
            continue
        if isinstance(v, str) and len(v) > 12000:
            out[k] = v[:12000] + f"\n...[truncated {len(v) - 12000} chars]"
            out[k + "_truncated"] = True
        else:
            out[k] = v
    return out


def audit(event: dict[str, Any]) -> None:
    APP_DIR.mkdir(parents=True, exist_ok=True)
    event = {"ts": utc_now(), **sanitize_audit_event(event)}
    line = json.dumps(event, ensure_ascii=False, sort_keys=True) + "\n"
    with audit_lock:
        with AUDIT.open("a", encoding="utf-8") as f:
            f.write(line)
        try:
            os.chmod(AUDIT, 0o600)
        except Exception:
            pass


def read_tail(path: Path, lines: int = 100) -> list[str]:
    if not path.exists():
        return []
    # Simple and safe enough for current audit size; cap lines.
    lines = max(1, min(lines, 1000))
    return path.read_text(encoding="utf-8", errors="replace").splitlines()[-lines:]


def json_bytes(obj: Any, status: int = 200) -> tuple[int, bytes]:
    return status, (json.dumps(obj, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def first_word(cmd: str) -> str:
    try:
        parts = shlex.split(cmd, posix=(os.name != "nt"))
    except Exception:
        parts = cmd.strip().split()
    if not parts:
        return ""
    return Path(parts[0]).name.lower().removesuffix(".exe")


def blocked_reason(cmd: str) -> str | None:
    low = cmd.lower()
    for pat in BLOCK_PATTERNS:
        if re.search(pat, low, flags=re.I | re.S):
            return f"blocked by safety pattern: {pat}"
    return None


def under_root(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except Exception:
        return False


def read_limited(path: Path, max_bytes: int) -> tuple[str, bool, int]:
    size = path.stat().st_size if path.exists() else 0
    with path.open("rb") as f:
        data = f.read(max_bytes + 1)
    truncated = len(data) > max_bytes or size > max_bytes
    data = data[:max_bytes]
    return data.decode("utf-8", "replace"), truncated, size


class BridgeHTTPServer(ThreadingHTTPServer):
    daemon_threads = True


class BridgeHandler(BaseHTTPRequestHandler):
    server_version = f"ArenaLocalBridge/{VERSION}"

    def log_message(self, fmt: str, *args: Any) -> None:
        sys.stderr.write("[%s] %s\n" % (utc_now(), fmt % args))

    @property
    def cfg(self):
        return self.server.cfg  # type: ignore[attr-defined]

    def send_json(self, obj: Any, status: int = 200) -> None:
        code, data = json_bytes(obj, status)
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def unauthorized(self) -> None:
        self.send_json({"ok": False, "error": "unauthorized"}, 401)

    def check_auth(self) -> bool:
        return self.headers.get("Authorization", "") == f"Bearer {self.cfg['token']}"

    def read_json(self) -> dict[str, Any] | None:
        try:
            length = int(self.headers.get("Content-Length", "0") or "0")
        except ValueError:
            self.send_json({"ok": False, "error": "invalid content-length"}, 400); return None
        if length > MAX_BODY:
            self.send_json({"ok": False, "error": "body too large"}, 413); return None
        raw = self.rfile.read(length) if length else b"{}"
        try:
            data = json.loads(raw.decode("utf-8"))
            if not isinstance(data, dict):
                raise ValueError("JSON must be object")
            return data
        except Exception as e:
            self.send_json({"ok": False, "error": f"invalid json: {e}"}, 400); return None

    def common_status(self) -> dict[str, Any]:
        return {
            "ok": True,
            "service": "arena-local-bridge",
            "version": VERSION,
            "host": socket.gethostname(),
            "platform": platform.platform(),
            "python": sys.version.split()[0],
            "profile": self.cfg["profile"],
            "root": str(self.cfg["root"]),
            "auth_required_for_exec": True,
            "active_exec": self.cfg["active_exec"],
            "max_concurrent": self.cfg["max_concurrent"],
            "audit": str(AUDIT),
        }

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path
        
        if path == "/v1/download":
            if not self.check_auth():
                self.unauthorized(); return
            qs = parse_qs(parsed.query)
            target = qs.get("path", [""])[0]
            if not target:
                self.send_json({"ok": False, "error": "missing path"}, 400); return
            target_path = Path(target).expanduser()
            if not target_path.is_absolute():
                target_path = self.cfg["root"] / target_path
            if not target_path.exists() or not target_path.is_file():
                self.send_json({"ok": False, "error": "file not found"}, 404); return
            
            try:
                size = target_path.stat().st_size
                self.send_response(200)
                self.send_header("Content-Type", "application/octet-stream")
                self.send_header("Content-Length", str(size))
                self.send_header("Content-Disposition", f'attachment; filename="{target_path.name}"')
                self.end_headers()
                with target_path.open("rb") as f:
                    import shutil
                    shutil.copyfileobj(f, self.wfile)
                audit({"type": "file_download", "path": str(target_path), "bytes": size})
            except Exception as e:
                pass # HTTP headers likely already sent, so just abort
            return

        if path == "/":
            self.send_json({
                "ok": True,
                "service": "arena-local-bridge",
                "version": VERSION,
                "endpoints": ["/health", "/v1/info", "/v1/status", "/v1/audit?lines=100", "POST /v1/exec", "POST /v1/upload?path=", "GET /v1/download?path=", "GET /v1/sysinfo", "GET /v1/ps", "POST /v1/kill"],
                "auth_required_for_exec": True,
            })
            return
        if path == "/health":
            s = self.common_status()
            # Public health deliberately omits audit path and active details.
            for k in ["audit", "active_exec", "max_concurrent", "python"]:
                s.pop(k, None)
            self.send_json(s)
            return
        if path in {"/v1/info", "/v1/status"}:
            if not self.check_auth(): self.unauthorized(); return
            self.send_json(self.common_status())
            return
        
        
        if path == "/gui":
            html_path = self.cfg["root"] / "arena-agent/dashboard/index.html"
            if html_path.exists():
                html = html_path.read_text(encoding='utf-8')
                html = html.replace("{{TOKEN}}", self.cfg["token"])
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.end_headers()
                self.wfile.write(html.encode('utf-8'))
            else:
                self.send_response(404)
                self.end_headers()
            return

        if path == "/v1/sysinfo":
            if not self.check_auth(): self.unauthorized(); return
            try:
                import shutil, multiprocessing
                disk = shutil.disk_usage(self.cfg["root"])
                mem_total, mem_avail = 0, 0
                if os.path.exists("/proc/meminfo"):
                    with open("/proc/meminfo") as f:
                        m = f.read()
                        import re
                        match_t = re.search(r"MemTotal:\s+(\d+)", m)
                        match_a = re.search(r"MemAvailable:\s+(\d+)", m)
                        if match_t: mem_total = int(match_t.group(1)) * 1024
                        if match_a: mem_avail = int(match_a.group(1)) * 1024
                load = getattr(os, "getloadavg", lambda: (0.0, 0.0, 0.0))()
                self.send_json({
                    "ok": True,
                    "cpu_cores": multiprocessing.cpu_count(),
                    "load_avg": load,
                    "mem_total_mb": mem_total // (1024*1024),
                    "mem_avail_mb": mem_avail // (1024*1024),
                    "disk_total_gb": disk.total // (1024**3),
                    "disk_free_gb": disk.free // (1024**3)
                })
            except Exception as e:
                self.send_json({"ok": False, "error": str(e)}, 500)
            return

        if path == "/v1/ps":
            if not self.check_auth(): self.unauthorized(); return
            ps_list = []
            for req_id, info in ACTIVE_PROCESSES.items():
                ps_list.append({
                    "request_id": req_id,
                    "pid": info["proc"].pid,
                    "cmd": info["cmd"][:200],
                    "uptime_sec": round(time.time() - info["start"], 1)
                })
            self.send_json({"ok": True, "processes": ps_list, "count": len(ps_list)})
            return

        if path == "/v1/audit":
            if not self.check_auth(): self.unauthorized(); return
            qs = parse_qs(parsed.query)
            try:
                n = int(qs.get("lines", ["100"])[0])
            except ValueError:
                n = 100
            rows = []
            for line in read_tail(AUDIT, n):
                try:
                    rows.append(json.loads(line))
                except Exception:
                    rows.append({"raw": line})
            self.send_json({"ok": True, "lines": len(rows), "audit": str(AUDIT), "events": rows})
            return
        self.send_json({"ok": False, "error": "not found"}, 404)

    
    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path

        
        if path == "/v1/kill":
            if not self.check_auth(): self.unauthorized(); return
            data = self.read_json()
            if not data: return
            target_id = data.get("request_id")
            if not target_id or target_id not in ACTIVE_PROCESSES:
                self.send_json({"ok": False, "error": "process not found"}, 404); return
            
            proc = ACTIVE_PROCESSES[target_id]["proc"]
            try:
                if os.name == "posix":
                    os.killpg(proc.pid, signal.SIGKILL)
                else:
                    proc.kill()
                self.send_json({"ok": True, "killed": target_id})
                audit({"type": "process_killed", "target_request_id": target_id, "client": self.client_address[0]})
            except Exception as e:
                self.send_json({"ok": False, "error": str(e)}, 500)
            return

        if path == "/v1/upload":
            if not self.check_auth():
                self.unauthorized(); return
            qs = parse_qs(parsed.query)
            target = qs.get("path", [""])[0]
            if not target:
                self.send_json({"ok": False, "error": "missing path"}, 400); return
            target_path = Path(target).expanduser()
            if not target_path.is_absolute():
                target_path = self.cfg["root"] / target_path
            
            try:
                length = int(self.headers.get("Content-Length", "0"))
                # Allow larger bodies for upload, e.g., 50MB
                if length > 50 * 1024 * 1024:
                    self.send_json({"ok": False, "error": "file too large (max 50MB)"}, 413); return
                
                target_path.parent.mkdir(parents=True, exist_ok=True)
                with target_path.open("wb") as f:
                    if length > 0:
                        f.write(self.rfile.read(length))
                
                audit({"type": "file_upload", "path": str(target_path), "bytes": length})
                self.send_json({"ok": True, "path": str(target_path), "bytes": length})
            except Exception as e:
                self.send_json({"ok": False, "error": repr(e)}, 500)
            return

        if path != "/v1/exec":
            self.send_json({"ok": False, "error": "not found"}, 404); return
        if not self.check_auth():
            self.unauthorized(); return
        data = self.read_json()
        if data is None: return
        request_id = str(data.get("request_id") or uuid.uuid4())
        cmd = str(data.get("cmd", "")).strip()
        if not cmd:
            self.send_json({"ok": False, "error": "missing cmd", "request_id": request_id}, 400); return

        reason = blocked_reason(cmd)
        if reason:
            audit({"type": "exec_blocked", "request_id": request_id, "cmd": cmd, "reason": reason, "client": self.client_address[0]})
            self.send_json({"ok": False, "error": reason, "request_id": request_id}, 403); return

        profile = self.cfg["profile"]
        fw = first_word(cmd)
        if profile == "cautious" and fw not in CAUTIOUS_ALLOW:
            reason = f"command '{fw}' is not in cautious allowlist; restart bridge with --profile owner-shell if intended"
            audit({"type": "exec_blocked", "request_id": request_id, "cmd": cmd, "reason": reason, "client": self.client_address[0]})
            self.send_json({"ok": False, "error": reason, "request_id": request_id}, 403); return

        root: Path = self.cfg["root"]
        cwd_raw = str(data.get("cwd") or root)
        cwd = Path(cwd_raw).expanduser()
        if not cwd.is_absolute(): cwd = root / cwd
        if not self.cfg["allow_any_cwd"] and not under_root(cwd, root):
            self.send_json({"ok": False, "error": f"cwd must be under root {root}", "request_id": request_id}, 403); return
        if not cwd.exists() or not cwd.is_dir():
            self.send_json({"ok": False, "error": f"cwd does not exist or is not a directory: {cwd}", "request_id": request_id}, 400); return

        timeout = min(int(data.get("timeout", self.cfg["timeout"])), self.cfg["max_timeout"])
        max_output = min(int(data.get("max_output", DEFAULT_MAX_OUTPUT)), self.cfg["max_output"])
        env_extra = data.get("env") if isinstance(data.get("env"), dict) else {}
        env = os.environ.copy(); env.update({str(k): str(v) for k, v in env_extra.items()})

        sem: threading.BoundedSemaphore = self.cfg["semaphore"]
        if not sem.acquire(blocking=False):
            self.send_json({"ok": False, "error": "too many concurrent exec requests", "request_id": request_id}, 429); return

        self.cfg["active_exec"] += 1
        RUN_DIR.mkdir(parents=True, exist_ok=True)
        run_dir = Path(tempfile.mkdtemp(prefix=f"{request_id}-", dir=str(RUN_DIR)))
        stdout_path, stderr_path = run_dir / "stdout.txt", run_dir / "stderr.txt"
        audit({"type": "exec_start", "request_id": request_id, "cmd": cmd, "cwd": str(cwd), "timeout": timeout, "client": self.client_address[0]})
        t0 = time.time(); timed_out = False; proc = None
        try:
            with stdout_path.open("wb") as out, stderr_path.open("wb") as err:
                popen_kwargs: dict[str, Any] = dict(shell=True, cwd=str(cwd), env=env, stdout=out, stderr=err)
                
                def preexec():
                    if os.name == "posix":
                        os.setsid()
                        try:
                            mb = 1024 * 1024
                            resource.setrlimit(resource.RLIMIT_AS, (16384 * mb, 16384 * mb))
                        except Exception:
                            pass
                if sys.platform != "win32": popen_kwargs["preexec_fn"] = preexec

                
                proc = subprocess.Popen(cmd, **popen_kwargs)
                ACTIVE_PROCESSES[request_id] = {"cmd": cmd, "proc": proc, "start": time.time()}

                try:
                    exit_code = proc.wait(timeout=timeout)
                except subprocess.TimeoutExpired:
                    timed_out = True
                    if os.name == "posix":
                        try: os.killpg(proc.pid, signal.SIGTERM)
                        except Exception: pass
                        time.sleep(0.5)
                        if proc.poll() is None:
                            try: os.killpg(proc.pid, signal.SIGKILL)
                            except Exception: pass
                    else:
                        try: proc.kill()
                        except Exception: pass
                    exit_code = proc.wait(timeout=5) if proc.poll() is None else proc.returncode
            duration = round(time.time() - t0, 3)
            stdout, trunc_out, stdout_bytes = read_limited(stdout_path, max_output)
            stderr, trunc_err, stderr_bytes = read_limited(stderr_path, max_output)
            truncated = trunc_out or trunc_err
            ok = (not timed_out) and exit_code == 0
            event_type = "exec_timeout" if timed_out else "exec_done"
            audit({"type": event_type, "request_id": request_id, "cmd": cmd, "exit_code": exit_code, "duration": duration, "truncated": truncated, "stdout_bytes": stdout_bytes, "stderr_bytes": stderr_bytes})
            self.send_json({
                "ok": ok,
                "request_id": request_id,
                "exit_code": exit_code,
                "duration_sec": duration,
                "cwd": str(cwd),
                "stdout": stdout,
                "stderr": stderr,
                "truncated": truncated,
                "stdout_bytes": stdout_bytes,
                "stderr_bytes": stderr_bytes,
                "error": f"timeout after {timeout}s" if timed_out else None,
            }, 408 if timed_out else 200)
        except Exception as e:
            duration = round(time.time() - t0, 3)
            audit({"type": "exec_error", "request_id": request_id, "cmd": cmd, "duration": duration, "error": repr(e)})
            self.send_json({"ok": False, "request_id": request_id, "error": repr(e), "duration_sec": duration}, 500)
        
        finally:
            ACTIVE_PROCESSES.pop(request_id, None)
            self.cfg["active_exec"] -= 1

            sem.release()
            # Keep temp files only for current request duration; audit has byte counts.
            try:
                for p in [stdout_path, stderr_path]:
                    if p.exists(): p.unlink()
                run_dir.rmdir()
            except Exception:
                pass


def serve(args: argparse.Namespace) -> None:
    token = args.token or os.environ.get("ARENA_LOCAL_BRIDGE_TOKEN")
    if not token:
        print("No token provided. Generate one with `python local_bridge.py token` and pass --token or ARENA_LOCAL_BRIDGE_TOKEN.", file=sys.stderr)
        raise SystemExit(2)
    root = Path(args.root).expanduser().resolve(); root.mkdir(parents=True, exist_ok=True)
    cfg = {
        "token": token,
        "profile": args.profile,
        "root": root,
        "allow_any_cwd": args.allow_any_cwd,
        "timeout": args.timeout,
        "max_timeout": args.max_timeout,
        "max_output": args.max_output,
        "max_concurrent": args.max_concurrent,
        "semaphore": threading.BoundedSemaphore(args.max_concurrent),
        "active_exec": 0,
    }
    server = BridgeHTTPServer((args.bind, args.port), BridgeHandler)
    server.cfg = cfg  # type: ignore[attr-defined]
    print(f"Arena Local Bridge v{VERSION} listening on http://{args.bind}:{args.port}", flush=True)
    print(f"profile={args.profile} root={root} audit={AUDIT} max_concurrent={args.max_concurrent}", flush=True)
    print("Stop with Ctrl+C. Do not expose this without a tunnel/access policy and a strong temporary token.", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        server.server_close()


def token_cmd(_: argparse.Namespace) -> None:
    print(b64_token())


def client(args: argparse.Namespace) -> None:
    import urllib.request
    payload = json.dumps({"cmd": args.cmd, "cwd": args.cwd, "timeout": args.timeout, "max_output": args.max_output}, ensure_ascii=False).encode()
    req = urllib.request.Request(args.url.rstrip("/") + "/v1/exec", data=payload, headers={"Content-Type": "application/json", "Authorization": f"Bearer {args.token}"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=args.timeout + 10) as r:
            print(r.read().decode("utf-8", "replace"))
    except Exception as e:
        print(repr(e), file=sys.stderr); raise SystemExit(1)


def main() -> None:
    p = argparse.ArgumentParser(description="Arena Local Bridge")
    sub = p.add_subparsers(dest="cmd", required=True)
    sp = sub.add_parser("token", help="generate a strong random token"); sp.set_defaults(func=token_cmd)
    sp = sub.add_parser("serve", help="run local command bridge")
    sp.add_argument("--bind", default="127.0.0.1")
    sp.add_argument("--port", type=int, default=8765)
    sp.add_argument("--token")
    sp.add_argument("--root", default=str(Path.home()))
    sp.add_argument("--allow-any-cwd", action="store_true")
    sp.add_argument("--profile", choices=["cautious", "owner-shell"], default="cautious")
    sp.add_argument("--timeout", type=int, default=60)
    sp.add_argument("--max-timeout", type=int, default=600)
    sp.add_argument("--max-output", type=int, default=DEFAULT_MAX_OUTPUT)
    sp.add_argument("--max-concurrent", type=int, default=DEFAULT_MAX_CONCURRENT)
    sp.set_defaults(func=serve)
    sp = sub.add_parser("client", help="test a bridge endpoint")
    sp.add_argument("--url", default="http://127.0.0.1:8765")
    sp.add_argument("--token", required=True)
    sp.add_argument("--cwd")
    sp.add_argument("--timeout", type=int, default=30)
    sp.add_argument("--max-output", type=int, default=DEFAULT_MAX_OUTPUT)
    sp.add_argument("cmd")
    sp.set_defaults(func=client)
    args = p.parse_args(); args.func(args)


if __name__ == "__main__":
    main()

